package com.qa.testscripts;

import org.testng.annotations.Test;

@Test
public class TC_ProductRegistration_02 extends TestBase
{

}
